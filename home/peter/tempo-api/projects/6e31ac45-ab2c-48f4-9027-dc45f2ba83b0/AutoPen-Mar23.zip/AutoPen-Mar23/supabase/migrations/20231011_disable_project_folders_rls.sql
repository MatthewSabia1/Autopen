-- Disable RLS on project_folders table
ALTER TABLE public.project_folders DISABLE ROW LEVEL SECURITY;

-- Disable RLS on folder_projects table
ALTER TABLE public.folder_projects DISABLE ROW LEVEL SECURITY; 