Need to install the following packages:
supabase@2.19.7
Ok to proceed? (y) 
